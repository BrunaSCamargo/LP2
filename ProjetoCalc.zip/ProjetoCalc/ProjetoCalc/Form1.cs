﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {
                Close();

            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número inválido");
                txtNumero2.Focus();

            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();

        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!","Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumero2.Focus();
            }

            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();

            }
        }

        private void TxtResultado_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = String.Empty;
            txtNumero2.Text = String.Empty;
            txtResultado.Text = String.Empty;

            txtNumero1.Focus();
            resultado = 0;
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
          
            if(!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número inválido");
                txtNumero1.Focus();

            }
        }
    }
}
