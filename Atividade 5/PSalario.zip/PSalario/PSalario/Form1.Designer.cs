﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAINSS = new System.Windows.Forms.Label();
            this.lblAIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblDINSS = new System.Windows.Forms.Label();
            this.lblDIRPF = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtAINSS = new System.Windows.Forms.TextBox();
            this.txtAIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDINSS = new System.Windows.Forms.TextBox();
            this.txtDIRPF = new System.Windows.Forms.TextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.btnDesconto = new System.Windows.Forms.Button();
            this.nupdFilho = new System.Windows.Forms.NumericUpDown();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilho)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(25, 25);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(137, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário:";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(25, 59);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(105, 20);
            this.lblSalario.TabIndex = 1;
            this.lblSalario.Text = "Salário Bruto:";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(25, 94);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(132, 20);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de filhos:";
            // 
            // lblAINSS
            // 
            this.lblAINSS.AutoSize = true;
            this.lblAINSS.Location = new System.Drawing.Point(25, 250);
            this.lblAINSS.Name = "lblAINSS";
            this.lblAINSS.Size = new System.Drawing.Size(113, 20);
            this.lblAINSS.TabIndex = 3;
            this.lblAINSS.Text = "Aliquota INSS:";
            // 
            // lblAIRPF
            // 
            this.lblAIRPF.AutoSize = true;
            this.lblAIRPF.Location = new System.Drawing.Point(25, 289);
            this.lblAIRPF.Name = "lblAIRPF";
            this.lblAIRPF.Size = new System.Drawing.Size(112, 20);
            this.lblAIRPF.TabIndex = 4;
            this.lblAIRPF.Text = "Aliquota IRPF:";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(25, 328);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(116, 20);
            this.lblSalFamilia.TabIndex = 5;
            this.lblSalFamilia.Text = "Salário Família:";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(25, 368);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(117, 20);
            this.lblSalLiquido.TabIndex = 6;
            this.lblSalLiquido.Text = "Salário Liquido:";
            // 
            // lblDINSS
            // 
            this.lblDINSS.AutoSize = true;
            this.lblDINSS.Location = new System.Drawing.Point(379, 250);
            this.lblDINSS.Name = "lblDINSS";
            this.lblDINSS.Size = new System.Drawing.Size(124, 20);
            this.lblDINSS.TabIndex = 7;
            this.lblDINSS.Text = "Desconto INSS:";
            // 
            // lblDIRPF
            // 
            this.lblDIRPF.AutoSize = true;
            this.lblDIRPF.Location = new System.Drawing.Point(379, 289);
            this.lblDIRPF.Name = "lblDIRPF";
            this.lblDIRPF.Size = new System.Drawing.Size(123, 20);
            this.lblDIRPF.TabIndex = 8;
            this.lblDIRPF.Text = "Desconto IRPF:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(177, 22);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(383, 26);
            this.txtNome.TabIndex = 9;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // txtAINSS
            // 
            this.txtAINSS.Enabled = false;
            this.txtAINSS.Location = new System.Drawing.Point(177, 244);
            this.txtAINSS.Name = "txtAINSS";
            this.txtAINSS.Size = new System.Drawing.Size(143, 26);
            this.txtAINSS.TabIndex = 11;
            this.txtAINSS.TextChanged += new System.EventHandler(this.txtAINSS_TextChanged);
            // 
            // txtAIRPF
            // 
            this.txtAIRPF.Enabled = false;
            this.txtAIRPF.Location = new System.Drawing.Point(177, 283);
            this.txtAIRPF.Name = "txtAIRPF";
            this.txtAIRPF.Size = new System.Drawing.Size(143, 26);
            this.txtAIRPF.TabIndex = 12;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(177, 322);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(143, 26);
            this.txtSalFamilia.TabIndex = 13;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(177, 365);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(143, 26);
            this.txtSalLiquido.TabIndex = 14;
            // 
            // txtDINSS
            // 
            this.txtDINSS.Enabled = false;
            this.txtDINSS.Location = new System.Drawing.Point(524, 244);
            this.txtDINSS.Name = "txtDINSS";
            this.txtDINSS.Size = new System.Drawing.Size(141, 26);
            this.txtDINSS.TabIndex = 15;
            // 
            // txtDIRPF
            // 
            this.txtDIRPF.Enabled = false;
            this.txtDIRPF.Location = new System.Drawing.Point(524, 286);
            this.txtDIRPF.Name = "txtDIRPF";
            this.txtDIRPF.Size = new System.Drawing.Size(141, 26);
            this.txtDIRPF.TabIndex = 16;
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(177, 56);
            this.mskbxSalBruto.Mask = "90000.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(114, 26);
            this.mskbxSalBruto.TabIndex = 17;
            // 
            // btnDesconto
            // 
            this.btnDesconto.Location = new System.Drawing.Point(75, 154);
            this.btnDesconto.Name = "btnDesconto";
            this.btnDesconto.Size = new System.Drawing.Size(206, 33);
            this.btnDesconto.TabIndex = 18;
            this.btnDesconto.Text = "Verifica Desconto";
            this.btnDesconto.UseVisualStyleBackColor = true;
            this.btnDesconto.Click += new System.EventHandler(this.btnDesconto_Click);
            // 
            // nupdFilho
            // 
            this.nupdFilho.Location = new System.Drawing.Point(177, 88);
            this.nupdFilho.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nupdFilho.Name = "nupdFilho";
            this.nupdFilho.Size = new System.Drawing.Size(120, 26);
            this.nupdFilho.TabIndex = 19;
            this.nupdFilho.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(341, 154);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(133, 33);
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(533, 154);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(132, 33);
            this.btnSair.TabIndex = 21;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.nupdFilho);
            this.Controls.Add(this.btnDesconto);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.txtDIRPF);
            this.Controls.Add(this.txtDINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAIRPF);
            this.Controls.Add(this.txtAINSS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblDIRPF);
            this.Controls.Add(this.lblDINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAIRPF);
            this.Controls.Add(this.lblAINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilho)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAINSS;
        private System.Windows.Forms.Label lblAIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblDINSS;
        private System.Windows.Forms.Label lblDIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtAINSS;
        private System.Windows.Forms.TextBox txtAIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDINSS;
        private System.Windows.Forms.TextBox txtDIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.Button btnDesconto;
        private System.Windows.Forms.NumericUpDown nupdFilho;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSair;
    }
}

