﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double salbruto, salFam, salLiq,
            descINSS, descIRPF, filhos;

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNome.Text = string.Empty;
            mskbxSalBruto.Text = string.Empty;  
            txtAINSS.Text = string.Empty;   
            txtAIRPF.Text = string.Empty;
            txtSalFamilia.Text = string.Empty;
            txtSalLiquido.Text = string.Empty;
            txtDINSS.Text = string.Empty;
            txtDIRPF.Text = string.Empty;
            salbruto = 0;
            salFam = 0;
            salLiq = 0;
            descINSS = 0;
            descIRPF = 0;
            filhos = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtAINSS_TextChanged(object sender, EventArgs e)
        {
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "") 
            {
                MessageBox.Show("Nome inválido!!");
            }

        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            salbruto = Convert.ToDouble(mskbxSalBruto.Text);

            if (salbruto <= 800.47)
            {
                txtAINSS.Text = "7.65%";
                descINSS = salbruto * 0.0765;
                txtDINSS.Text = descINSS.ToString();
            }
            else
            {
                if (salbruto <= 1050)
                {
                    txtAINSS.Text = "8.65%";
                    descINSS = salbruto * 0.0865;
                    txtDINSS.Text = descINSS.ToString();
                }
                else
                {
                    if (salbruto <= 1400.77)
                    {
                        txtAINSS.Text = "9.00%";
                        descINSS = salbruto * 0.09;
                        txtDINSS.Text = descINSS.ToString();
                    }
                    else
                    {
                        if (salbruto <= 2801.56)
                        {
                            txtAINSS.Text = "11.00%";
                            descINSS = salbruto * 0.11;
                            txtDINSS.Text = descINSS.ToString();
                        }
                        else
                        {
                            txtAINSS.Text = "Teto";
                            descINSS = 308.17;
                            txtDINSS.Text = descINSS.ToString();
                        }
                    }
                }
            }

            if (salbruto <= 1257.12)
            {
                txtAIRPF.Text = "Isento";
                txtDIRPF.Text = "Isento";
                descIRPF = 0;
            }
            else
            {
                if (salbruto <= 2512.08)
                {
                    txtAIRPF.Text = "15.00%";
                    descIRPF = salbruto * 0.15;
                    txtDIRPF.Text = descIRPF.ToString();
                }
                else
                {
                    txtAIRPF.Text = "27.5%";
                    descIRPF = salbruto * 0.275;
                    txtDIRPF.Text = descIRPF.ToString();
                }
            }

            if (salbruto <= 435.52)
            {
                filhos = Convert.ToDouble(nupdFilho.Value);
                salFam = filhos * 22.33;
                txtSalFamilia.Text = salFam.ToString();
            }
            else
            {
                if (salbruto <= 654.61)
                {
                    filhos = Convert.ToDouble(nupdFilho.Value);
                    salFam = filhos * 15.74;
                    txtSalFamilia.Text = salFam.ToString();
                }
                else
                {
                    salFam = 0;
                    txtSalFamilia.Text = salFam.ToString();
                }
            }

            salLiq = salbruto - descINSS - descIRPF + salFam;
            txtSalLiquido.Text = salLiq.ToString();
        }
    }
}
