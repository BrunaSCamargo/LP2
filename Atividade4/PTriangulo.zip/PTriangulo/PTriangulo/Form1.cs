﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Text = string.Empty;
            txtLado2.Text = string.Empty;
            txtLado3.Text = string.Empty;
            txtResultado.Text = string.Empty;
            txtLado1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado1.Text, out lado1) || (lado1<=0))
            {
                MessageBox.Show("Número inválido!");
                txtLado1.Focus();
            }
        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado2.Text, out lado2) || (lado2 <= 0))
            {
                MessageBox.Show("Número inválido!");
                txtLado2.Focus();
            }

        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLado3.Text, out lado3) || (lado3 <= 0))
            {
                MessageBox.Show("Número inválido!");
                txtLado3.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(lado2 - lado3) < lado1 && (lado2 + lado3) > lado1) &&
            (Math.Abs(lado1 - lado3) < lado2 && (lado1 + lado3) > lado2) &&
            (Math.Abs(lado1 - lado2) < lado3 && lado3 < (lado1 + lado3)))
            {

                if (lado1 == lado2 && lado2 == lado3)
                {
                    txtResultado.Text = ("Triângulo Equilátero");
                }
                else
                    if (((lado1 == lado2 || lado1 == lado3) || lado2 == lado3) && (lado1 != lado2 || lado2 != lado3))
                {
                    txtResultado.Text = ("Triângulo Isósceles");
                }
                else
                    if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3)
                {
                    txtResultado.Text = ("Triângulo Escaleno");
                }
                {

                }
            }
        }
    }
}
