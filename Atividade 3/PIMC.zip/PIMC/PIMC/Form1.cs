﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxPeso, "");

            if (!double.TryParse(mskbxPeso.Text, out peso) && (peso > 0))
            {
                MessageBox.Show("Peso inválido!!");
                errorProvider1.SetError(mskbxPeso, "Peso inválido");
            }
        }

        private void MskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MskbxAltura_Validated(object sender, EventArgs e)
        {
            double altura;
            errorProvider1.SetError(mskbxAltura, "");

            if (!double.TryParse(mskbxAltura.Text, out altura) && (altura > 0))
            {
                MessageBox.Show("Altura inválida!!");
                errorProvider2.SetError(mskbxAltura, "Altura inválida");
            }
        }

        private void TxtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double pesoAtual, altura, imc; 

            if(double.TryParse(mskbxAltura.Text, out altura) && double.TryParse(mskbxPeso.Text, out pesoAtual))
            {
                if ((altura <= 0) || (pesoAtual <= 0))
                    MessageBox.Show("Valores devem ser maiores que zero!");
                else
                {
                    imc = pesoAtual / (Math.Pow(altura, 2));

                    imc = Math.Round(imc, 1);

                    txtIMC.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        txtIMC.Text += "    Classificação: Magreza";
                    else if (imc <= 24.9)
                        txtIMC.Text += "    Classificação: Normal";
                    else if (imc <= 29.9)
                        txtIMC.Text += "    Classificação: Sobrepeso";
                    else if (imc <= 39.9)
                        txtIMC.Text += "    Classificação: Obesidade";
                    else
                        txtIMC.Text += "    Classificação: Obesidade Grave";

                }
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Text = String.Empty;
            mskbxAltura.Text = String.Empty;
            txtIMC.Text = String.Empty;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
