﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerrificar_Click(object sender, EventArgs e)
        {
            double[,] valor = new double[6,4];
            string aux = "";
            double total = 0;

            double geral = 0;
            double mes = 0;

            for (int a = 1; a < 7; a++)
            {
                for (var i = 1; i < 5; i++)
                {
                    aux = Interaction.InputBox("Digite um valor", "Entrada de Dados");


                        listBox1.Items.Add("Total do mes: " + a + " Semana: " + i + " " + aux);

                        mes += Convert.ToDouble(aux);
                        
                        geral += Convert.ToDouble(aux);
                    
                }

                total = total + Convert.ToDouble(aux);

                aux = "";
                //mes = mes.ToString();

                listBox1.Items.Add("Total mes: " + mes.ToString());
                    

                mes = 0;

            }

            listBox1.Items.Add("Total geral: " + geral);


        }
    }
}
