﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtFrase = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnNum = new System.Windows.Forms.Button();
            this.btnPBranco = new System.Windows.Forms.Button();
            this.btnCLetras = new System.Windows.Forms.Button();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.txtLetra = new System.Windows.Forms.TextBox();
            this.txtBranco = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rctxtFrase
            // 
            this.rctxtFrase.Location = new System.Drawing.Point(92, 73);
            this.rctxtFrase.Name = "rctxtFrase";
            this.rctxtFrase.Size = new System.Drawing.Size(541, 117);
            this.rctxtFrase.TabIndex = 0;
            this.rctxtFrase.Text = "";
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(32, 121);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(50, 20);
            this.lblFrase.TabIndex = 1;
            this.lblFrase.Text = "Frase";
            // 
            // btnNum
            // 
            this.btnNum.Location = new System.Drawing.Point(92, 229);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(106, 61);
            this.btnNum.TabIndex = 2;
            this.btnNum.Text = "Conta Número";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // btnPBranco
            // 
            this.btnPBranco.Location = new System.Drawing.Point(312, 229);
            this.btnPBranco.Name = "btnPBranco";
            this.btnPBranco.Size = new System.Drawing.Size(106, 61);
            this.btnPBranco.TabIndex = 3;
            this.btnPBranco.Text = "Primeiro Branco";
            this.btnPBranco.UseVisualStyleBackColor = true;
            this.btnPBranco.Click += new System.EventHandler(this.btnPBranco_Click);
            // 
            // btnCLetras
            // 
            this.btnCLetras.Location = new System.Drawing.Point(527, 229);
            this.btnCLetras.Name = "btnCLetras";
            this.btnCLetras.Size = new System.Drawing.Size(106, 61);
            this.btnCLetras.TabIndex = 4;
            this.btnCLetras.Text = "Conta Letras";
            this.btnCLetras.UseVisualStyleBackColor = true;
            this.btnCLetras.Click += new System.EventHandler(this.btnCLetras_Click);
            // 
            // txtNumero
            // 
            this.txtNumero.Enabled = false;
            this.txtNumero.Location = new System.Drawing.Point(92, 304);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(106, 26);
            this.txtNumero.TabIndex = 5;
            // 
            // txtLetra
            // 
            this.txtLetra.Enabled = false;
            this.txtLetra.Location = new System.Drawing.Point(527, 304);
            this.txtLetra.Name = "txtLetra";
            this.txtLetra.Size = new System.Drawing.Size(106, 26);
            this.txtLetra.TabIndex = 6;
            this.txtLetra.TextChanged += new System.EventHandler(this.txtLetra_TextChanged);
            // 
            // txtBranco
            // 
            this.txtBranco.Enabled = false;
            this.txtBranco.Location = new System.Drawing.Point(312, 304);
            this.txtBranco.Name = "txtBranco";
            this.txtBranco.Size = new System.Drawing.Size(106, 26);
            this.txtBranco.TabIndex = 7;
            this.txtBranco.TextChanged += new System.EventHandler(this.txtBranco_TextChanged);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtBranco);
            this.Controls.Add(this.txtLetra);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.btnCLetras);
            this.Controls.Add(this.btnPBranco);
            this.Controls.Add(this.btnNum);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.rctxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtFrase;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnPBranco;
        private System.Windows.Forms.Button btnCLetras;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.TextBox txtLetra;
        private System.Windows.Forms.TextBox txtBranco;
    }
}