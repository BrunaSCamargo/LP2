﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            int cont = 0;

            for (var i = 0; i < rctxtFrase.Text.Length; i++)
            {
                if (char.IsNumber(rctxtFrase.Text[i]))
                    cont++;
            }

            txtNumero.Text = cont.ToString();
        }

        private void txtLetra_TextChanged(object sender, EventArgs e)
        {
            {
                
            }
        }

        private void txtBranco_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int cont = 0;

            while (cont < rctxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rctxtFrase.Text[cont]))
                {
                    posicao = cont + 1;
                }
                if (posicao > 0)
                    txtBranco.Text = posicao.ToString();
                else
                    txtBranco.Text = ("Não há espaço em branco");
                cont++;
            }
        }

        private void btnCLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach (var c in rctxtFrase.Text)
            {
                if (char.IsLetter(c))
                    cont++;
            }

            txtLetra.Text = cont.ToString();
        }
    }
}
